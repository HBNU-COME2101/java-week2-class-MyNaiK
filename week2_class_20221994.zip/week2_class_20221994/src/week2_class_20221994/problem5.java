package week2_class_20221994;

import java.util.Scanner;

public class problem5 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("나이를 입력하세요>>");
		int age = scanner.nextInt();
		
		int red = age / 10;
		int blue = (age - red * 10) / 5;
		int yellow = (age - red * 10 - blue * 5);
		
		int total = red + blue + yellow;
		
		if(red != 0) {
			System.out.print("빨간 초 " + red + "개");
			if(blue == 0 && yellow == 0) {
				System.out.print(". ");
			}
			else {
				System.out.print(", ");
			}
		}
		
		if(blue != 0) {
			System.out.print("파란 초 " + blue + "개");
			if(yellow == 0) {
				System.out.print(". ");
			}
			else {
				System.out.print(", ");
			}
		}
		
		if(yellow != 0) {
			System.out.print("노란 초 " + yellow + "개. ");
		}
		
		System.out.println("총 " + total + "개가 필요합니다.");
	}	
}
