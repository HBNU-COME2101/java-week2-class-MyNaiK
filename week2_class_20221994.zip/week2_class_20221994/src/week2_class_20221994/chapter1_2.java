package week2_class_20221994;

public class chapter1_2 {
	public static void main(String[] args) {
		System.out.println("20221994");
		System.out.println("송강현");
	}
}
