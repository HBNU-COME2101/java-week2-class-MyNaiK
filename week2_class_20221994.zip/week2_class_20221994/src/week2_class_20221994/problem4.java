package week2_class_20221994;

import java.util.Scanner;

public class problem4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("여행지 >> ");
		String location = scanner.nextLine();
		
		System.out.print("인원수 >> ");
		int people = scanner.nextInt();
		
		System.out.print("숙박일 >> ");
		int date = scanner.nextInt();
		int date2 = date + 1;
		
		System.out.print("1인당 항공료 >> ");
		int flight = scanner.nextInt();
		
		System.out.print("1방 숙박비 >> ");
		int hotel = scanner.nextInt();
		
		int needhotel;
		if(people % 2 == 0) {
			needhotel = people / 2;
		}
		else {
			needhotel = people / 2 + 1;
		}
		
		int money = (flight * people) + (hotel * needhotel * date);
		
		System.out.println(people + "명의 " + location + " " + date + "박 " + date2 + "일 여행에는 " + needhotel + "개 필요하며 경비는 " + money + " 원입니다.");
	}
}
